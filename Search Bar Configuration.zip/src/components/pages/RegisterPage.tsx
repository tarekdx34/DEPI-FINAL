import { useState } from "react";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { RadioGroup, RadioGroupItem } from "../ui/radio-group";
import { ImageWithFallback } from "../figma/ImageWithFallback";
import { Language, translations } from "../../lib/translations";
import { Globe } from "lucide-react";

interface RegisterPageProps {
  onNavigate: (page: string) => void;
  initialRole?: "renter" | "owner";
  onRegister?: (name: string, email: string, password: string, role: "renter" | "owner") => void;
  language?: Language;
  onLanguageChange?: (lang: Language) => void;
}

export function RegisterPage({ onNavigate, initialRole = "renter", onRegister, language = "en", onLanguageChange }: RegisterPageProps) {
  const t = translations[language].register;
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    password: "",
    confirmPassword: "",
    nationalId: "",
    role: initialRole,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (onRegister) {
      onRegister(formData.fullName, formData.email, formData.password, formData.role);
    } else {
      // Fallback if no onRegister provided
      if (formData.role === "owner") {
        onNavigate("host-dashboard");
      } else {
        onNavigate("user-dashboard");
      }
    }
  };

  const handleChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const toggleLanguage = () => {
    if (onLanguageChange) {
      onLanguageChange(language === "en" ? "ar" : "en");
    }
  };

  return (
    <div className="min-h-screen flex">
      {/* Language Toggle - Fixed Top Right */}
      <button
        onClick={toggleLanguage}
        className="fixed top-4 right-4 z-50 flex items-center gap-2 px-4 py-2 bg-white/90 backdrop-blur-sm hover:bg-white border border-gray-200 rounded-full shadow-lg transition-all hover:shadow-xl"
        title={language === "en" ? "Switch to Arabic" : "التبديل إلى الإنجليزية"}
      >
        <Globe className="w-4 h-4 text-[#00BFA6]" />
        <span className="font-medium text-sm">
          {language === "en" ? "العربية" : "EN"}
        </span>
      </button>

      {/* Left Side - Image */}
      <div className="hidden lg:block lg:flex-1 relative">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1729720281771-b790dfb6ec7f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBiZWFjaCUyMHZpbGxhfGVufDF8fHx8MTc2MTA5ODc1Nnww&ixlib=rb-4.1.0&q=80&w=1080"
          alt="Luxury Villa"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#00BFA6]/20 to-transparent" />
        <div className="absolute inset-0 flex items-center justify-center p-12">
          <div className="text-white text-center">
            <h2 className="text-4xl font-bold mb-4">
              {language === "ar" ? "انضم إلى أجارلي اليوم" : "Join Ajarly Today"}
            </h2>
            <p className="text-xl text-white/90">
              {language === "ar" ? "ابدأ رحلتك إلى تجارب لا تُنسى" : "Start your journey to unforgettable experiences"}
            </p>
          </div>
        </div>
      </div>

      {/* Right Side - Form */}
      <div className="flex-1 flex items-center justify-center px-4 sm:px-6 lg:px-8 py-12">
        <div className="max-w-md w-full space-y-8">
          <div>
            <button
              onClick={() => onNavigate("home")}
              className="flex items-center gap-2 mb-8 hover:opacity-80 transition-opacity"
            >
              <div className="w-10 h-10 bg-[#00BFA6] rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-xl">A</span>
              </div>
              <span className="font-bold text-2xl text-[#2B2B2B]">Ajarly</span>
            </button>

            <h2 className="text-3xl font-bold text-[#2B2B2B]">{t.createAccount}</h2>
            <p className="mt-2 text-gray-600">
              {language === "ar" ? "ابدأ مغامرتك مع أجارلي" : "Start your adventure with Ajarly"}
            </p>
          </div>

          <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
            <div className="space-y-4">
              <div>
                <Label htmlFor="fullName">{t.nameLabel}</Label>
                <Input
                  id="fullName"
                  name="fullName"
                  type="text"
                  required
                  value={formData.fullName}
                  onChange={(e) => handleChange("fullName", e.target.value)}
                  className="mt-1"
                  placeholder={t.namePlaceholder}
                />
              </div>

              <div>
                <Label htmlFor="email">{t.emailLabel}</Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  autoComplete="email"
                  required
                  value={formData.email}
                  onChange={(e) => handleChange("email", e.target.value)}
                  className="mt-1"
                  placeholder={t.emailPlaceholder}
                />
              </div>

              <div>
                <Label htmlFor="password">{t.passwordLabel}</Label>
                <Input
                  id="password"
                  name="password"
                  type="password"
                  autoComplete="new-password"
                  required
                  value={formData.password}
                  onChange={(e) => handleChange("password", e.target.value)}
                  className="mt-1"
                  placeholder={t.passwordPlaceholder}
                />
              </div>

              <div>
                <Label htmlFor="confirmPassword">{t.confirmPasswordLabel}</Label>
                <Input
                  id="confirmPassword"
                  name="confirmPassword"
                  type="password"
                  autoComplete="new-password"
                  required
                  value={formData.confirmPassword}
                  onChange={(e) => handleChange("confirmPassword", e.target.value)}
                  className="mt-1"
                  placeholder={t.confirmPasswordPlaceholder}
                />
              </div>

              <div>
                <Label htmlFor="nationalId">
                  {language === "ar" ? "الرقم القومي" : "National ID"}
                </Label>
                <Input
                  id="nationalId"
                  name="nationalId"
                  type="text"
                  required
                  value={formData.nationalId}
                  onChange={(e) => handleChange("nationalId", e.target.value)}
                  className="mt-1"
                  placeholder="29912345678910"
                />
              </div>

              <div>
                <Label className="mb-3 block">
                  {language === "ar" ? "أريد أن" : "I want to"}
                </Label>
                <RadioGroup
                  value={formData.role}
                  onValueChange={(value) => handleChange("role", value)}
                  className="flex gap-4"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="renter" id="renter" />
                    <Label htmlFor="renter" className="font-normal cursor-pointer">
                      {t.asRenter}
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="owner" id="owner" />
                    <Label htmlFor="owner" className="font-normal cursor-pointer">
                      {t.asHost}
                    </Label>
                  </div>
                </RadioGroup>
              </div>
            </div>

            <div className="flex items-start">
              <input
                id="terms"
                name="terms"
                type="checkbox"
                required
                className="h-4 w-4 text-[#00BFA6] focus:ring-[#00BFA6] border-gray-300 rounded mt-1"
              />
              <label htmlFor="terms" className={`${language === "ar" ? "mr-2" : "ml-2"} block text-sm text-gray-900`}>
                {t.agreeToTerms}{" "}
                <button
                  type="button"
                  onClick={() => onNavigate("terms")}
                  className="text-[#00BFA6] hover:text-[#00A890]"
                >
                  {t.termsAndConditions}
                </button>{" "}
                {t.and}{" "}
                <button
                  type="button"
                  onClick={() => onNavigate("privacy-policy")}
                  className="text-[#00BFA6] hover:text-[#00A890]"
                >
                  {t.privacyPolicy}
                </button>
              </label>
            </div>

            <div>
              <Button
                type="submit"
                className="w-full bg-[#FF6B6B] hover:bg-[#FF5252] text-white"
                size="lg"
              >
                {t.createAccountButton}
              </Button>
            </div>

            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-300" />
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white text-gray-500">
                  {language === "ar" ? "أو تابع مع" : "Or continue with"}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <Button type="button" variant="outline" className="w-full">
                <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24">
                  <path
                    fill="currentColor"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="currentColor"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="currentColor"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                  />
                  <path
                    fill="currentColor"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                  />
                </svg>
                Google
              </Button>
              <Button type="button" variant="outline" className="w-full">
                <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                </svg>
                Facebook
              </Button>
            </div>

            <p className="text-center text-sm text-gray-600">
              {t.alreadyHaveAccount}{" "}
              <button
                type="button"
                onClick={() => onNavigate("login")}
                className="font-medium text-[#00BFA6] hover:text-[#00A890]"
              >
                {t.signIn}
              </button>
            </p>
          </form>
        </div>
      </div>
    </div>
  );
}