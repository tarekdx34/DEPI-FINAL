
  # Search Bar Configuration

  This is a code bundle for Search Bar Configuration. The original project is available at https://www.figma.com/design/1wYzxxi7tYBa7vQw0KwRcg/Search-Bar-Configuration.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  